var accounts;
var accountID = 0;

function add()
{
var sig= signature.deployed();
  sig.initTransac(150,{from:account}).then(function(rslt){
   console.log("transac mise en place");
   console.log(rslt);
   sig.addHash(rslt,{from:account}).then(function(result){
console.log(result);
console.log("en attente de la signature definitive");
   });
 }).catch(function(e){
  console.log("erreur");
  console.log(e);
});
}

function toSign()
{
  var sig = signature.deployed();
  sig.toSign({from:account}).then(function(rslt){
console.log(rslt);
console.log("signé");
  }).catch(function(e){
    console.log("erreur");
    console.log(e);
  });
}

function getSommeControl()
{
var sign = signature.deployed();
sign.getSomme().then(function(rslt){
console.log(rslt);
document.getElementById("somme").innerHTML=rslt.toString(10);
});
}

function getHashControl()
{
var sign = signature.deployed();
sign.getHash().then(function(rslt){
console.log(rslt.toString(10));
document.getElementById("transac").innerHTML=rslt.toString(10);
});
}
function getIndexInfo()
{
var sign = signature.deployed();
sign.getIndex().then(function(rslt){
console.log("resultat1    "+rslt.toString(10));
sign.getSomme(rslt.toString(10)-1).then(function(result){
console.log("resultat 2    "+result.toString(10));
});
// document.getElementById("transac").innerHTML=rslt;
});
}

// function getInfo()
// {
//   var dem=Vote.deployed();
//   dem.getIndex().then(function(rslt){
//     var i = rslt.toString(10)-1 ;
//     console.log("la proposition est la numéro"+i);
//   dem.proposals(i).then(function(result){
//   console.log(result);
//   document.getElementById("des").innerHTML=result[0];
//     // document.getElementById("time").innerHTML=result[2].toString(10);
//   document.getElementById("numbervote").innerHTML=result[4].toString(10);
//   getTime(i);
//   });
//   });
// }

window.onload = function() {
  web3.eth.getAccounts(function(err, accs) {
    if (err != null) {
      alert("There was an error fetching your accounts.");
      return;
    }

    if (accs.length == 0) {
      alert("Couldn't get any accounts! Make sure your Ethereum client is configured correctly.");
      return;
    }
        accounts = accs;
    account = accounts[accountID];
  });
}
